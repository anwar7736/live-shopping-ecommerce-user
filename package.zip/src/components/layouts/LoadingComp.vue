<template>
    <div class="text-center">
        <img src="assets/images/loading/loading-waiting.gif" alt="" height="200" width="200">
    </div>
</template>
<script>
export default {
    
}
</script>
<style>
    
</style>