<template>
    <div>
        <h1>Forget Password</h1>
    </div>
</template>
<script>
export default {
    data(){
        return {
            
        }
    }
}
</script>
<style>
    
</style>