<template>
    <div>
        <center>
            <h1 class="not-found">404 | Page Not Found!</h1>
        </center>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>
    .not-found{
        margin:100px;
        color:red;
    }
</style>