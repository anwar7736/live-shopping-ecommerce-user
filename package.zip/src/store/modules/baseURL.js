const baseURL = "https://advertbangladesh.com/testpos/api";

export default baseURL;