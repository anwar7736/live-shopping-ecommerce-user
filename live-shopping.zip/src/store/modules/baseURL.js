const baseURL = "https://advert.com.bd/new_pos/api";

export default baseURL;