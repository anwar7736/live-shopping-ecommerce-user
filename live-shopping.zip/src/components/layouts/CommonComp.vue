<template>
    <div>
        <section>
            <div class="features pt-4 pb-4 ps-3 pe-3" style="background-color: #ed6c00;">
                <div class="container-fluid">
                    <div class="row feature-row">
                        <div class="col-lg col-md-4 col-12 feature-col m-auto text-start p-2">
                            <div class="d-flex feature-flex">
                                <div class="icon text-center">
                                    <img src="assets/images/svg/delivery2.svg" alt="" height="40" class="mt-2 pe-2">
                                </div>
                                <div class="text text-light">
                                    <h6><b>CASH ON DELIVERY</b></h6>
                                    <p>Shipping all over the country</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg col-md-4 col-12 feature-col m-auto text-start p-2">
                            <div class="d-flex feature-flex">
                                <div class="icon text-center">
                                    <img src="assets/images/svg/best-price.svg" alt="" height="40" class="mt-2 pe-2">
                                </div>
                                <div class="text text-light">
                                    <h6><b>BEST PRICE</b></h6>
                                    <p>Buy wholesale & retail</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg col-md-4 col-12 feature-col m-auto text-start p-2">
                            <div class="d-flex feature-flex">
                                <div class="icon text-center">
                                    <img src="assets/images/svg/support.svg" alt="" height="40" class="mt-2 pe-2">
                                </div>
                                <div class="text text-light">
                                    <h6><b>24/7 SUPPORT</b></h6>
                                    <p>Unlimited help desk.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg col-md-4 col-12 feature-col m-auto text-start p-2">
                            <div class="d-flex feature-flex">
                                <div class="icon text-center">
                                    <img src="assets/images/svg/protection.svg" alt="" height="40" class="mt-2 pe-2">
                                </div>
                                <div class="text text-light">
                                    <h6><b>BUYER PROTECTION</b></h6>
                                    <p>Pay only when you receive goods</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg col-md-4 col-12 feature-col m-auto text-start p-2">
                            <div class="d-flex feature-flex">
                                <div class="icon text-center">
                                    <img src="assets/images/svg/return.svg" alt="" height="40" class="mt-2 pe-2">
                                </div>
                                <div class="text text-light">
                                    <h6><b>07 DAYS RETURN</b></h6>
                                    <p>Easy return policy for online purchase</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>
<script>
export default {
    
}
</script>
<style>
    
</style>